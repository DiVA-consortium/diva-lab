﻿Imports System.Xml
Imports System.Net
Imports System.IO

Public Class ex2
    Inherits System.Web.UI.Page

    'Declare variables
    Private DiVAID, abstract, issn, OutputISSN, OutputAll, POSTData, SiteContent, dt_DiVAID, dt_issn, dt_abstract, dt_subjectCatID, ResponseContent, HSVCode, HSVTopic, Score, Message As String
    Private ModsID, SubjectCatID As Integer

    'Declare namespace for Mods XML
    Private ns As XNamespace = "http://www.loc.gov/mods/v3"
    Private xlink As XNamespace = "http://www.w3.org/1999/xlink"

    'Get publications from DiVA for the last seven days
    Private DiVArequest As String = "http://liu.diva-portal.org/smash/export.jsf?format=mods&aq=[[{""datePublished"":""[NOW-7DAY TO NOW]""}]]&aqe=[]&aq2=[[]]&onlyFullText=false&noOfRows=1000&sortOrder=title_sort_asc"

    Private dt As DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'This happens when loading the page

        Dim Watch As Stopwatch = New Stopwatch
        Watch.Start()
        Dim settings As New XmlReaderSettings()
        settings.IgnoreWhitespace = False

        'Create datatable to store values
        dt = New DataTable
        dt.Columns.Add("DiVAID")
        dt.Columns.Add("issn")
        dt.Columns.Add("abstract")
        dt.Columns.Add("subjectCatID")

        'Create a XML reader to read from DiVA
        Using reader As XmlReader = XmlReader.Create(DiVArequest, settings)

            While reader.ReadToFollowing("mods")

                'Clear values before reading each <mods> node
                If reader.Name = "mods" Then
                    clearValues()
                End If

                'Create a subtree for each tag <mods> i.e. DiVA record
                Using subtree_mods As XmlReader = reader.ReadSubtree

                    'Read through subtree "mods"
                    subtree_mods.Read()

                    'Load <mods> element as a XElement
                    Dim MODS_Element As XElement = XElement.Load(subtree_mods.ReadSubtree)

                    Dim MODS_Nodes As IEnumerable(Of XElement) = MODS_Element.Elements()

                    'Iterate through all child nodes in <mods>
                    For Each el In MODS_Nodes

                        'Get DiVA-id
                        DiVAID = DiVAID & If(el.Name = ns + "identifier" And el.Attribute("type") = "uri", el.Value, [String].Empty)

                        'Get Abstract
                        abstract = abstract & If(el.Name = ns + "abstract" And el.Attribute("lang") = "eng", el.Value, [String].Empty)

                        'Get Subject category ID (HSV)
                        If el.Name = ns + "subject" And el.Attribute("authority") = "hsv" Then
                            SubjectCatID = el.Attribute(xlink + "href").Value
                        End If

                        'Get issn
                        If el.Name = ns + "relatedItem" And el.Attribute("type") = "host" Then
                            Dim issn_data =
                            From element In MODS_Nodes.Descendants(ns + "identifier")
                            Where CStr(element.Attribute("type") = "issn")
                            Select element

                            For Each xEle As XElement In issn_data
                                issn = xEle.Value
                            Next
                        End If
                    Next

                End Using

                dt.Rows.Add(DiVAID, issn, abstract, SubjectCatID)

            End While
        End Using

        SiteContent = String.Empty

        'Read the the first 10 rows (just for presentation use "For i = 0 to dt.rows.count -1" to get all rows selected from DiVA)
        For i = 0 To 10

            'Reset Output string before each DiVA record
            OutputISSN = String.Empty
            OutputAll = String.Empty

            dt_DiVAID = dt.Rows(i)("DiVAID")
            dt_abstract = dt.Rows(i)("abstract")
            dt_issn = dt.Rows(i)("issn")
            dt_subjectCatID = dt.Rows(i)("subjectCatID")

            'If Not dt_abstract = String.Empty And IsValidISSN(dt_issn) = True And dt_subjectCatID.Length < 2 Then
            If Not dt_abstract = String.Empty And IsValidISSN(dt_issn) = True Then
                Try

                    'Remove html tag
                    dt_abstract = StripTags(dt_abstract)

                    Dim SubjectCategoryrequest As HttpWebRequest = WebRequest.Create("http://www.ep.liu.se/subject_categories/")
                    SubjectCategoryrequest.Method = "POST"
                    SubjectCategoryrequest.KeepAlive = True

                    Dim postData As String = String.Format("abstract={0}&issn={1}&language{2}", dt_abstract, dt_issn, "en")
                    Dim byteArray As Byte() = System.Text.Encoding.UTF8.GetBytes(postData)
                    SubjectCategoryrequest.ContentLength = byteArray.Length
                    SubjectCategoryrequest.ContentType = "application/x-www-form-urlencoded"

                    Dim dataStream As Stream

                    dataStream = SubjectCategoryrequest.GetRequestStream()
                    dataStream.Write(byteArray, 0, byteArray.Length)
                    dataStream.Close()

                    Dim ServerResponse As WebResponse = SubjectCategoryrequest.GetResponse()

                    'Get the stream containing content returned by the server.
                    dataStream = ServerResponse.GetResponseStream()

                    ' Open the stream using a StreamReader for easy access.
                    Dim ResponseReader As New StreamReader(dataStream)
                    ResponseContent = ResponseReader.ReadToEnd()

                    'Create a XML reader to read the XML with subject categories
                    Using ReadSubjectCategories As XmlReader = XmlReader.Create(New StringReader(ResponseContent))

                        While ReadSubjectCategories.ReadToFollowing("results")

                            Dim CategoryResults As XElement = XElement.Load(ReadSubjectCategories.ReadSubtree)

                            Dim Nodes As IEnumerable(Of XElement) = CategoryResults.Elements()

                            For Each el In Nodes

                                If el.Name = "hsv-ISSN" Then

                                    Dim HSV_Data_ISSN As IEnumerable(Of XElement) = el.Elements()
                                    For Each ChildElement In HSV_Data_ISSN

                                        HSVCode = ChildElement.Descendants("code").Value
                                        HSVTopic = ChildElement.Descendants("topic").Value
                                        Score = ChildElement.Descendants("score").Value

                                        OutputISSN = OutputISSN & "Ämneskategori: " & HSVTopic & "<br />" & "Kod: " & HSVCode & "<br />" & "Score: " & Score & "<br /><br />"
                                    Next

                                End If

                                If el.Name = "hsv-all" Then

                                    Dim HSV_Data_all As IEnumerable(Of XElement) = el.Elements()
                                    For Each ChildElement In HSV_Data_all

                                        HSVCode = ChildElement.Descendants("code").Value
                                        HSVTopic = ChildElement.Descendants("topic").Value
                                        Score = ChildElement.Descendants("score").Value

                                        OutputAll = OutputAll & "Ämneskategori: " & HSVTopic & "<br />" & "Kod: " & HSVCode & "<br />" & "Score: " & Score & "<br /><br />"
                                    Next

                                End If
                            Next
                        End While

                        SiteContent = SiteContent & "<div class=""DiVARecord"">" & dt_DiVAID & "<br /><h5>Förslag baserat på medskickat ISSN</h5>" & OutputISSN & "<h5>Förslag baserat på alla ämnesområden</h5>" & OutputAll & "</div>"

                    End Using

                    ResponseReader.Close()
                    dataStream.Close()
                    ServerResponse.Close()

                Catch ex As WebException
                    System.Diagnostics.Debug.WriteLine(ex.Message)

                    If ex.Status = WebExceptionStatus.ProtocolError Then
                        System.Diagnostics.Debug.WriteLine(CType(ex.Response, HttpWebResponse).StatusCode)
                        System.Diagnostics.Debug.WriteLine(CType(ex.Response, HttpWebResponse).StatusDescription)
                    End If

                End Try
            End If

        Next

        DiVARecord.InnerHtml = SiteContent
        Watch.Stop()
        StopWatch.InnerHtml = "Sökningen tog:" & Space(2) & Watch.ElapsedMilliseconds & Space(2) & "Millisekunder"
    End Sub
    Private Sub clearValues()

        'Function to clear all values before reading next <mods> node

        DiVAID = String.Empty
        issn = String.Empty
        abstract = String.Empty
        SubjectCatID = 0
    End Sub

    Private Function IsValidISSN(strIn As String) As Boolean

        'Function to validate if ISSN is in correct format.

        If Regex.IsMatch(strIn, "^\d{4}-\d{3}[\dxX]$") Then
            Return True
        Else
            Return False
        End If
    End Function

    Function StripTags(ByVal html As String) As String

        ' Remove HTML tags.
        Return Regex.Replace(html, "<.*?>", "")
    End Function
End Class