﻿Imports System.Xml

Public Class ex1
    Inherits System.Web.UI.Page

    'Declare variables
    Private authors, authority, authorAffiliation, PubType, PubTitle, PubSubTitle, DiVAID, DOI, Source, SourcesubTitle, SourceCategory, Series, PubStatus, PubYear, PubVolume, PubIssue, PubPageStart, PubPageEnd, FulltextURL, LastName, FirstName, Name, Userid, RecordCreationDate, AffOwnOrg, Output, SiteContent As String
    Private ModsID, AuthorPosition As Integer

    'Declare namespace for Mods XML
    Private ns As XNamespace = "http://www.loc.gov/mods/v3"
    Private xlink As XNamespace = "http://www.w3.org/1999/xlink"

    'Get publications from DiVA for the last seven days
    Private DiVArequest As String = "http://liu.diva-portal.org/smash/export.jsf?format=mods&aq=[[{""datePublished"":""[NOW-7DAY TO NOW]""}]]&aqe=[]&aq2=[[]]&onlyFullText=false&noOfRows=1000&sortOrder=title_sort_asc"

    Private dt, dt_people As DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'This happens when loading the page

        Dim Watch As Stopwatch = New Stopwatch
        Watch.Start()
        Dim settings As New XmlReaderSettings()
        settings.IgnoreWhitespace = False

        ModsID = 0
        AuthorPosition = 0
        Output = String.Empty
        SiteContent = String.Empty

        'Create datatable for publication data (not authors)
        dt = New DataTable
        dt.Columns.Add("PubType")
        dt.Columns.Add("PubTitle")
        dt.Columns.Add("PubSubTitle")
        dt.Columns.Add("Source")
        dt.Columns.Add("SourcesubTitle")
        dt.Columns.Add("Series")
        dt.Columns.Add("DiVAID")
        dt.Columns.Add("DOI")
        dt.Columns.Add("PubStatus")
        dt.Columns.Add("PubYear")
        dt.Columns.Add("PubVolume")
        dt.Columns.Add("PubIssue")
        dt.Columns.Add("PubPageStart")
        dt.Columns.Add("PubPageEnd")
        dt.Columns.Add("FulltextURL")
        dt.Columns.Add("ModsID")
        dt.Columns.Add("RecordCreationDate")

        'Create datatable för authors
        dt_people = New DataTable
        dt_people.Columns.Add("authority")
        dt_people.Columns.Add("Userid")
        dt_people.Columns.Add("AuthorPosition")
        dt_people.Columns.Add("FirstName")
        dt_people.Columns.Add("LastName")
        dt_people.Columns.Add("authorAffiliation")
        dt_people.Columns.Add("AffOwnOrg")
        dt_people.Columns.Add("ModsID")


        'Create a XML reader to read from DiVA
        Using reader As XmlReader = XmlReader.Create(DiVArequest, settings)

            While reader.ReadToFollowing("mods")

                'Clear values before reading each <mods> node
                If reader.Name = "mods" Then
                    clearValues()
                End If

                'Create a subtree for each tag <mods> i.e. DiVA record
                Using subtree_mods As XmlReader = reader.ReadSubtree

                    'Read through subtree "mods"
                    subtree_mods.Read()

                    'Load <mods> element as a XElement
                    Dim MODS_Element As XElement = XElement.Load(subtree_mods.ReadSubtree)

                    Dim MODS_Nodes As IEnumerable(Of XElement) = MODS_Element.Elements()

                    'Iterate through all child nodes in <mods>
                    For Each el In MODS_Nodes

                        'Get publication type
                        PubType = PubType & If(el.Name = ns + "genre" And el.Attribute("type") = "publicationTypeCode", el.Value, String.Empty)

                        'Get Author names, userid if authority is LiU, affiliation
                        If el.Name = ns + "name" And el.Attribute("type") = "personal" Then

                            authority = If(el.Attribute("authority") IsNot Nothing, el.Attribute("authority").Value, String.Empty)

                            Userid = If(el.Attribute(xlink + "href") IsNot Nothing, el.Attribute(xlink + "href").Value, String.Empty)

                            AuthorPosition = AuthorPosition + 1

                            Dim LastName_data As IEnumerable(Of XElement) = From data In el.Elements(ns + "namePart") Where data.Attribute("type") = "family"
                            For Each ChildElement In LastName_data
                                LastName = ChildElement.Value
                            Next

                            Dim FirstName_data As IEnumerable(Of XElement) = From data In el.Elements(ns + "namePart") Where data.Attribute("type") = "given"
                            For Each ChildElement In FirstName_data
                                FirstName = ChildElement.Value
                            Next


                            authorAffiliation = If(el.Descendants(ns + "affiliation") IsNot Nothing, el.Descendants(ns + "affiliation").Value, String.Empty)

                            'Set AffOwnOrg to yes if affiliation starts with Linköping else set to no
                            If authorAffiliation IsNot Nothing Then
                                If authorAffiliation.Length > 8 Then
                                    If authorAffiliation.Substring(0, 9) = "Linköping" Then
                                        AffOwnOrg = "yes"
                                    Else
                                        AffOwnOrg = "no"
                                    End If
                                End If
                            End If

                            dt_people.Rows.Add(authority, Userid, AuthorPosition, FirstName, LastName, authorAffiliation, AffOwnOrg, ModsID)

                            'Reset AffOwnOrg after reading each author
                            AffOwnOrg = String.Empty

                        End If

                        'Get DiVA-id
                        DiVAID = DiVAID & If(el.Name = ns + "identifier" And el.Attribute("type") = "uri", el.Value, String.Empty)

                        'Get DOI
                        DOI = DOI & If(el.Name = ns + "identifier" And el.Attribute("type") = "doi", el.Value, String.Empty)

                        'Get PubTitle
                        PubTitle = PubTitle & If(el.Name = ns + "titleInfo", el.Value, String.Empty)

                        'Get PubYear
                        If el.Name = ns + "originInfo" Then
                            PubYear = If(el.Descendants(ns + "dateIssued") IsNot Nothing, el.Descendants(ns + "dateIssued").Value, String.Empty)
                        End If


                        'Get Source (Journal, Proceeding...)
                        If el.Name = ns + "relatedItem" And el.Attribute("type") = "host" Then
                            Dim Source_data As IEnumerable(Of XElement) = el.Elements().Descendants(ns + "title")
                            For Each ChildElement In Source_data
                                Source = ChildElement.Value
                            Next
                        End If

                        'Get Publication status
                        PubStatus = PubStatus & If(el.Name = ns + "note" And el.Attribute("type") = "publicationStatus", el.Value, String.Empty)

                    Next

                End Using

                dt.Rows.Add(PubType, PubTitle, PubSubTitle, Source, SourcesubTitle, Series, DiVAID, DOI, PubStatus, PubYear, PubVolume, PubIssue, PubPageStart, PubPageStart, FulltextURL, ModsID, RecordCreationDate)
            End While
        End Using

        'Read datatables and check for missing data
        For i = 0 To dt.Rows.Count - 1

            'Reset Output string before each DiVA record
            Output = String.Empty

            'If DOI is missing for a published article
            If dt.Rows(i)("PubType") = "article" And dt.Rows(i)("PubStatus") = "Published" And dt.Rows(i)("DOI") = String.Empty Then
                Output = Output & getErrorMessage(2) & "<br />"
            End If

            'If publication title is missing
            If dt.Rows(i)("PubTitle") = String.Empty Then
                Output = Output & getErrorMessage(3)
            End If

            'If PubYear is missing
            If dt.Rows(i)("PubYear").ToString() = String.Empty And dt.Rows(i)("PubStatus").ToString() = "Published" Then
                Output = Output & getErrorMessage(5) & "<br />"
            End If

            'Call function to check if affilitions and/or User-id is missing
            Dim authortableresults As ArrayList = checkAuthorTable(dt_people, dt.Rows(i)("ModsID"))

            If authortableresults.Count > 0 Then
                For Each element In authortableresults
                    Output = Output & element & "<br />"
                Next
            End If

            If Not Output = String.Empty Then
                SiteContent = SiteContent & "<div class = ""DiVARecord""><a href=" & dt.Rows(i)("DiVAID").ToString & " target = _blank>" & dt.Rows(i)("DiVAID").ToString & "</a><br />" & Output & "</div>"
            End If

        Next

        Watch.Stop()
        DiVARecord.InnerHtml = SiteContent
        StopWatch.InnerHtml = "Sökningen tog:" & Space(2) & Watch.ElapsedMilliseconds & Space(2) & "Millisekunder"

    End Sub

    Private Function getErrorMessage(errorCode As Integer) As String
        Dim message As String = String.Empty
        Dim dtErrorMessages As New DataTable
        dtErrorMessages.Columns.Add("errorCode", GetType(Integer))
        dtErrorMessages.Columns.Add("message", GetType(String))

        dtErrorMessages.Rows.Add(1, "Affiliering saknas för författare ")
        dtErrorMessages.Rows.Add(2, "DOI saknas.")
        dtErrorMessages.Rows.Add(3, "Publikationstitel saknas.")
        dtErrorMessages.Rows.Add(4, "Användar-ID saknas för författare ")
        dtErrorMessages.Rows.Add(5, "Publiceringsår saknas")

        Dim drow = dtErrorMessages.Select("errorCode = " & errorCode)
        message = drow(0)("message").ToString()

        Return message
    End Function

    Private Function checkAuthorTable(dtToCheck As DataTable, id As Integer)
        Dim resultsArray As New ArrayList

        'Query the table with author information passed to the function
        Dim rowselection = _
            From ModsIDColumn In dtToCheck.AsEnumerable() _
            Where ModsIDColumn.Field(Of String)("ModsID") = id _
            Select ModsIDColumn

        'Copy results from query to another datatable
        Dim dtselectedRows As DataTable = rowselection.CopyToDataTable

        For j = 0 To dtselectedRows.Rows.Count - 1

            'If affiliation is missing
            If dtselectedRows.Rows(j)("authorAffiliation").ToString() = String.Empty Then
                resultsArray.Add(getErrorMessage(1) & dtselectedRows.Rows(j)("AuthorPosition").ToString())
            End If

            'If user-id is missing
            If dtselectedRows.Rows(j)("Userid").ToString() = String.Empty And dtselectedRows.Rows(j)("AffOwnOrg").ToString() = "yes" Then
                resultsArray.Add(getErrorMessage(4) & dtselectedRows.Rows(j)("AuthorPosition").ToString())
            End If
        Next

        Return resultsArray
    End Function

    Private Sub clearValues()

        'Function to clear all values before reading next <mods> node

        authors = String.Empty
        authority = String.Empty
        authorAffiliation = String.Empty
        PubType = String.Empty
        PubTitle = String.Empty
        PubSubTitle = String.Empty
        DiVAID = String.Empty
        DOI = String.Empty
        Source = String.Empty
        SourcesubTitle = String.Empty
        SourceCategory = String.Empty
        Series = String.Empty
        PubStatus = String.Empty
        PubYear = String.Empty
        PubVolume = String.Empty
        PubIssue = String.Empty
        PubPageStart = String.Empty
        PubPageEnd = String.Empty
        FulltextURL = String.Empty
        Userid = String.Empty
        FirstName = String.Empty
        LastName = String.Empty
        Name = String.Empty
        RecordCreationDate = String.Empty
        AffOwnOrg = String.Empty

        ModsID = ModsID + 1
        AuthorPosition = 0
    End Sub

End Class