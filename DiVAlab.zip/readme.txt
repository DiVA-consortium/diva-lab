
Kommentarer till DIVA-lab Visual Studio Project

I mappen DIVA-lab.zip finns Visual Studio-projektet som innehåller de två övningar som användes vid första DIVA-lab-träffen 2016-03-15.
Ex1.vb innehåller kod i VB för att kvalitetsgranska poster. Koden är kommenterad till stora delar men för att förstå allt som händer behöver man sätta sig in i vad XML reader och LINQ to XML är för något.

Ex2.vb innehåller kod i VB för att generera ämneskategori med hjälp av Linköpings Electronix Press tjänst på http://www.ep.liu.se/hsv_categories/. Utifrån DiVA-data såsom ISSN och abstract görs ett HTTP Post-anrop och får då tillbaka en XML som läses återgiven med XML reader och LINQ to XMl.

Ex1.aspx respektive ex2.aspx innehåller html-kod för att visa resultatet på en webbsida.